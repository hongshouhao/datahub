// System.Web.Services.Description.HttpUrlEncodedBinding

[XmlFormatExtension("urlEncoded", "http://schemas.xmlsoap.org/wsdl/http/", typeof(InputBinding))]
public sealed class HttpUrlEncodedBinding : ServiceDescriptionFormatExtension
{
}
