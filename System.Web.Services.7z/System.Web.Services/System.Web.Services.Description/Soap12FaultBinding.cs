// System.Web.Services.Description.Soap12FaultBinding

[XmlFormatExtension("fault", "http://schemas.xmlsoap.org/wsdl/soap12/", typeof(FaultBinding))]
public sealed class Soap12FaultBinding : SoapFaultBinding
{
}
