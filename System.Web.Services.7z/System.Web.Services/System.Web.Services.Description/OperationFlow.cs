// System.Web.Services.Description.OperationFlow
public enum OperationFlow
{
    None,
    OneWay,
    Notification,
    RequestResponse,
    SolicitResponse
}
