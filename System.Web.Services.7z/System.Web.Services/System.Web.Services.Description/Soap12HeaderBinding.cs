// System.Web.Services.Description.Soap12HeaderBinding

[XmlFormatExtension("header", "http://schemas.xmlsoap.org/wsdl/soap12/", typeof(InputBinding), typeof(OutputBinding))]
public sealed class Soap12HeaderBinding : SoapHeaderBinding
{
}
