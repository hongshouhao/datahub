// System.Web.Services.Description.HttpUrlReplacementBinding

[XmlFormatExtension("urlReplacement", "http://schemas.xmlsoap.org/wsdl/http/", typeof(InputBinding))]
public sealed class HttpUrlReplacementBinding : ServiceDescriptionFormatExtension
{
}
