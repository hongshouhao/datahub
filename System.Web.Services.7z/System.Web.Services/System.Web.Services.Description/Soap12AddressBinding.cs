// System.Web.Services.Description.Soap12AddressBinding

[XmlFormatExtension("address", "http://schemas.xmlsoap.org/wsdl/soap12/", typeof(Port))]
public sealed class Soap12AddressBinding : SoapAddressBinding
{
}
