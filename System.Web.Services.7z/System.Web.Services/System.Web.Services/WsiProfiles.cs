// System.Web.Services.WsiProfiles
using System;

[Flags]
public enum WsiProfiles
{
    None = 0x0,
    BasicProfile1_1 = 0x1
}
